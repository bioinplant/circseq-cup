#!/usr/bin/perl -w
use strict;

#Parse segemehl splitmap.txt and convert it to fusion junction file that is acceptable for circseq_cup.

my $input = $ARGV[0];
my $output = $ARGV[1];
open IN, '<'.$input;
open OUT, '>'.$output;


while (<IN>){
     my $s=$_;
     chomp($s);   
     my @c=split(/\t/,$s);
     print OUT $c[0]."\t".($c[1]-1)."\t".$c[2]."\t".$c[3]."\t".$c[4]."\t".$c[5]."\n";
}

close IN1;
close OUT;
print "\n";